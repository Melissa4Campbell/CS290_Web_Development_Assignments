/*
* The value of the variable 'data' will be an array with at least 2 elements.
* All elements for the array 'data' will also be arrays.
* Each of these elements in 'data' will have the same number of elements.
*/

const data = [
    ['Company', 'Symbol', 'Price'],
    ['Microsoft', 'MSFT', '12.5'],
    ['Oracle', 'ORCL', '15.5'],
    ['Terrdada',' TRDT', '144']
];

export default data;