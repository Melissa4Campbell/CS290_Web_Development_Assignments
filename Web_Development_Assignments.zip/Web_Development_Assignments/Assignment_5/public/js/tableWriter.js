import data from './data.js';

// Don't change anything above this comment


// Feel free to define more functions if you want.


/**
 * Create and return an HTML table element using the value of variable 'data.'
 * The value of data is an array in which each element in turn is an array.
 * The top level array can have any number of elements greater than 1.
 * Each nested array will have the same number of elements.
 * This number will always be greater tha 0.
 * The HTML element created by this function will have as many columns
 * as the length of each nested array.
 * The elements in the first nested array (i.e., the array at index 0 in "data")
 * will be used to create <th> elements in the <thead> element of the table
 * The values of all other nested arrays will be used to create rows in the table,
 * one row for each of the other nested arrays, and using the value in a
 * nested array to create <td> elements in that row of the table.
 * @return HTML table element
 */
// public/js/tableWriter.js
// Assumes a global `data` array is defined in public/js/data.js

function createTableElement() {
  // make the <table>
  const table = document.createElement('table');

  // header
  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');

  const thCompany = document.createElement('th');
  thCompany.textContent = 'Company';

  const thQuantity = document.createElement('th');
  thQuantity.textContent = 'Quantity';

  headerRow.appendChild(thCompany);
  headerRow.appendChild(thQuantity);
  thead.appendChild(headerRow);
  table.appendChild(thead);

  // body
  const tbody = document.createElement('tbody');

  // `data` comes from data.js (the graders will swap that file)
  for (const item of data) {
    const tr = document.createElement('tr');

    const tdCompany = document.createElement('td');
    tdCompany.textContent = item.company;

    const tdQuantity = document.createElement('td');
    tdQuantity.textContent = item.quantity;

    tr.appendChild(tdCompany);
    tr.appendChild(tdQuantity);
    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  return table;
}

// mount the table after the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  // if the starter gave you a container, use it; else append to <body>
  const mount =
    document.getElementById('tableContainer') ||
    document.querySelector('#content') ||
    document.body;

  const table = createTableElement();
  mount.appendChild(table);
});

