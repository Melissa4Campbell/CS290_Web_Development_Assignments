import { Point2D } from './Point2D.mjs';

class Point3D extends Point2D {
  constructor(x, y, z) {
    super(x, y);
    this.z = z;
  }

  distanceFrom(p) {
    if (!(p instanceof Point3D)) {
      throw new TypeError('distanceFrom expects a Point3D');
    }
    const dx = this.x - p.x;
    const dy = this.y - p.y;
    const dz = this.z - p.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }
}

export { Point3D };


