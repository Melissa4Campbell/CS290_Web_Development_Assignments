/**
 * Models a point in 2 dimensions
 */
class Point2D {
  /**
   * @param {number} x The x-coordinate of the point
   * @param {number} y The y-coordinate of the point
   */
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  /**
   * @param {object} p An instance of the class Point2D
   * @returns The Euclidean distance between this point and p
   */
  distanceFrom(p) {
    if (!(p instanceof Point2D)) {
      throw new TypeError('distanceFrom expects a Point2D');
    }

    const dx = this.x - p.x;
    const dy = this.y - p.y;
    return Math.sqrt(dx * dx + dy * dy);
  }
}

export { Point2D };
