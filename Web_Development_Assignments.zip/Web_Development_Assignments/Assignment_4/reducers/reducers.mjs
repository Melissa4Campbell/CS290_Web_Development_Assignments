/*
* Don't change the declaration of this function.
*/

// reducers.mjs
function isFiniteNumber(v) {
  return typeof v === 'number' && Number.isFinite(v);
}

/*
* Don't change the declaration of this function.
*/
function reducer1(previousValue, currentValue){
  // If prev isn't a number (e.g., first element was non-numeric), treat as 0
  const acc = isFiniteNumber(previousValue) ? previousValue : 0;

  // Add current only if it's a finite number; otherwise skip it
  return isFiniteNumber(currentValue) ? acc + currentValue : acc;
};

/*
* Don't change the declaration of this function.
*/
function reducer2(previousValue, currentValue){
  // Throw if either prev or current is non-numeric (covers first element case)
  if (!isFiniteNumber(previousValue) || !isFiniteNumber(currentValue)) {
    throw new TypeError('Non-numeric value encountered');
  }
  return previousValue + currentValue;
};

// Don't add or change anything below this comment.
export { reducer1, reducer2 };
