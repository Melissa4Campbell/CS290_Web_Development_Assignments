import React from 'react';
import SelectQuantity from './SelectQuantity';

function OrderRow({ item }) {
  return (
    <tr>
      <td>{item.product}</td>
      <td>${item.price.toFixed(2)}</td>
      <td>
        <SelectQuantity />
      </td>
    </tr>
  );
}

export default OrderRow;