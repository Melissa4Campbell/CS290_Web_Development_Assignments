import React, { useState } from 'react';
import { GoDash, GoPlus } from 'react-icons/go';

function SelectQuantity() {
  const [quantity, setQuantity] = useState(0);

  const increment = () => {
    if (quantity < 10) {
      setQuantity(quantity + 1);
    }
  };

  const decrement = () => {
    if (quantity > 0) {
      setQuantity(quantity - 1);
    }
  };

  return (
    <div className="quantity-controls">
      <button onClick={decrement} className="quantity-btn">
        <GoDash />
      </button>
      <span className="quantity-value">{quantity}</span>
      <button onClick={increment} className="quantity-btn">
        <GoPlus />
      </button>
    </div>
  );
}

export default SelectQuantity;