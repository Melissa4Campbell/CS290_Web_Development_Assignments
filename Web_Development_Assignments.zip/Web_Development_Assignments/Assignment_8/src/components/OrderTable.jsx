import React from 'react';
import OrderRow from './OrderRow';

function OrderTable({ items }) {
  return (
    <table className="order-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Price</th>
          <th>Quantity</th>
        </tr>
      </thead>
      <tbody>
        {items.map((item, index) => (
          <OrderRow key={index} item={item} />
        ))}
      </tbody>
    </table>
  );
}

export default OrderTable;