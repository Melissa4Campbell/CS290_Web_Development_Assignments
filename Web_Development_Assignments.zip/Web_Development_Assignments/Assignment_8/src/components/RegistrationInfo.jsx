import React, { useState } from 'react';

function RegistrationInfo() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Thank you for registering!\n\nName: ${name}\nEmail: ${email}`);
  };

  return (
    <form onSubmit={handleSubmit} className="registration-form">
      <fieldset>
        <legend>Registration Information</legend>
        
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="submit-btn">Register</button>
      </fieldset>
    </form>
  );
}

export default RegistrationInfo;