import React from 'react';
import OrderTable from '../components/OrderTable';

function OrderPage({ items }) {
  return (
    <div className="page-container">
      <h2>Order Your Products</h2>
      <p>Select the quantity you want for each item using the + and - buttons.</p>
      <OrderTable items={items} />
    </div>
  );
}

export default OrderPage;