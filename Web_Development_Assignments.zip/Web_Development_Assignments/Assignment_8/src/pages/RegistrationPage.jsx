import React from 'react';
import RegistrationInfo from '../components/RegistrationInfo';

function RegistrationPage() {
  return (
    <div className="page-container">
      <h2>Register for Promotions</h2>
      <p>Sign up with your name and email to receive exclusive offers and updates.</p>
      <RegistrationInfo />
    </div>
  );
}

export default RegistrationPage;