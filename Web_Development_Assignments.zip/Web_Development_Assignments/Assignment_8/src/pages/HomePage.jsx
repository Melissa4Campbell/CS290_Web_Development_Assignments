import React from 'react';

function HomePage() {
  return (
    <div className="page-container">
      <h2>Welcome to Our Store</h2>
      <p>Browse our products on the Order page and register for exclusive promotions!</p>
    </div>
  );
}

export default HomePage;