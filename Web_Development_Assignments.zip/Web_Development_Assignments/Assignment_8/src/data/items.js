const items = [
    { name: 'Milk', price: 2.55 },
    { name: 'Pizza', price: 8.99 },
    { name: 'Mango', price: 4.00 },
	{ name: 'Strawberries', price: 17.99 },
	{ name: 'Yogurt', price: 8.95 },
	{ name: 'Red Raspberries', price: 12.44 },
	{ name: 'Sesame Seed Bagels', price: 8.95 },
	{ name: 'Organic Yogurt Tubes', price: 12.00 },
	{ name: 'Pears', price: 3.22 },
	{ name: 'Pasta Salad', price: 5.23 },
	{ name: 'Eggs 1 dozen', price: 3.59 },
];

export default items;