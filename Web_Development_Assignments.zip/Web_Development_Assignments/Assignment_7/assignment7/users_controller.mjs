import 'dotenv/config';
import express from 'express';
import asyncHandler from 'express-async-handler';
import * as users from './users_model.mjs';

const app = express();
app.use(express.json())

const PORT = process.env.PORT;

// DELETE /reset - Clear all users (helpful for testing)
app.delete('/reset', asyncHandler(async (req, res) => {
    const deletedCount = await users.clearAllUsers();
    res.status(200).json({ message: "All users cleared", deletedCount: deletedCount });
}));

// POST /users - Create a new user
app.post('/users', asyncHandler(async (req, res) => {
    const user = await users.createUser(req.body);
    res.status(201).json(user);
}));

// GET /users - Retrieve users (with optional filters)
app.get('/users', asyncHandler(async (req, res) => {
    const filter = {};
    
    if (req.query.name) filter.name = req.query.name;
    if (req.query.age) filter.age = req.query.age;
    if (req.query.email) filter.email = req.query.email;
    if (req.query.phoneNumber) filter.phoneNumber = req.query.phoneNumber;
    
    const usersList = await users.retrieveUsers(filter);
    res.status(200).json(usersList);
}));

// GET /users/:_id - Retrieve a user by ID
app.get('/users/:_id', asyncHandler(async (req, res) => {
    const user = await users.retrieveUserById(req.params._id);
    
    if (user) {
        res.status(200).json(user);
    } else {
        res.status(404).json({ Error: "Not found" });
    }
}));

// PUT /users/:_id - Update a user by ID
app.put('/users/:_id', asyncHandler(async (req, res) => {
    const user = await users.updateUser(req.params._id, req.body);
    
    if (user) {
        res.status(200).json(user);
    } else {
        res.status(404).json({ Error: "Not found" });
    }
}));

// DELETE /users/:_id - Delete a user by ID
app.delete('/users/:_id', asyncHandler(async (req, res) => {
    const deletedCount = await users.deleteUserById(req.params._id);
    
    if (deletedCount === 1) {
        res.status(204).send();
    } else {
        res.status(404).json({ Error: "Not found" });
    }
}));

// DELETE /users - Delete users by filter
app.delete('/users', asyncHandler(async (req, res) => {
    const filter = {};
    
    if (req.query.name) filter.name = req.query.name;
    if (req.query.age) filter.age = req.query.age;
    if (req.query.email) filter.email = req.query.email;
    if (req.query.phoneNumber) filter.phoneNumber = req.query.phoneNumber;
    
    const deletedCount = await users.deleteUsers(filter);
    res.status(200).json({ deletedCount: deletedCount });
}));

app.listen(PORT, async () => {
    await users.connect(false)
    console.log(`Server listening on port ${PORT}...`);
});
