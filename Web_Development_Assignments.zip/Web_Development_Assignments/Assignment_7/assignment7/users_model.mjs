// Get the mongoose object
import mongoose from 'mongoose';
import 'dotenv/config';

let connection = undefined;

/**
 * This function connects to the MongoDB server.
 */
async function connect(){
    try{
        await mongoose.connect(process.env.MONGODB_CONNECT_STRING);
        connection = mongoose.connection;
        console.log("Successfully connected to MongoDB using Mongoose!");
    } catch(err){
        console.log(err);
        throw Error(`Could not connect to MongoDB ${err.message}`)
    }
}

// Define the user schema
const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    email: { type: String, required: true },
    phoneNumber: { type: Number, required: false }
});

// Create the model
const User = mongoose.model('User', userSchema);

/**
 * Create a new user
 * @param {Object} user - User object with name, age, email, and optional phoneNumber
 * @returns {Promise} A promise that resolves to the created user document
 */
async function createUser(user) {
    const newUser = new User(user);
    return await newUser.save();
}

/**
 * Retrieve users based on filter criteria
 * @param {Object} filter - Filter object with optional properties: name, age, email, phoneNumber
 * @returns {Promise} A promise that resolves to an array of user documents
 */
async function retrieveUsers(filter) {
    const query = {};
    
    if (filter.name !== undefined) {
        query.name = filter.name;
    }
    if (filter.age !== undefined) {
        query.age = Number(filter.age);
    }
    if (filter.email !== undefined) {
        query.email = filter.email;
    }
    if (filter.phoneNumber !== undefined) {
        query.phoneNumber = Number(filter.phoneNumber);
    }
    
    return await User.find(query).exec();
}

/**
 * Retrieve a user by their _id
 * @param {String} _id - The MongoDB _id of the user
 * @returns {Promise} A promise that resolves to the user document or null if not found
 */
async function retrieveUserById(_id) {
    return await User.findById(_id).exec();
}

/**
 * Update a user by their _id
 * @param {String} _id - The MongoDB _id of the user
 * @param {Object} update - Object containing fields to update
 * @returns {Promise} A promise that resolves to the updated user document or null if not found
 */
async function updateUser(_id, update) {
    return await User.findByIdAndUpdate(_id, update, { new: true }).exec();
}

/**
 * Delete a user by their _id
 * @param {String} _id - The MongoDB _id of the user
 * @returns {Promise} A promise that resolves to the number of documents deleted
 */
async function deleteUserById(_id) {
    const result = await User.deleteOne({ _id: _id });
    return result.deletedCount;
}

/**
 * Delete users based on filter criteria
 * @param {Object} filter - Filter object with optional properties: name, age, email, phoneNumber
 * @returns {Promise} A promise that resolves to the number of documents deleted
 */
async function deleteUsers(filter) {
    const query = {};
    
    if (filter.name !== undefined) {
        query.name = filter.name;
    }
    if (filter.age !== undefined) {
        query.age = Number(filter.age);
    }
    if (filter.email !== undefined) {
        query.email = filter.email;
    }
    if (filter.phoneNumber !== undefined) {
        query.phoneNumber = Number(filter.phoneNumber);
    }
    
    const result = await User.deleteMany(query);
    return result.deletedCount;
}

/**
 * Clear all users from the database
 * @returns {Promise} A promise that resolves to the number of documents deleted
 */
async function clearAllUsers() {
    const result = await User.deleteMany({});
    return result.deletedCount;
}

export { 
    connect, 
    createUser, 
    retrieveUsers, 
    retrieveUserById, 
    updateUser, 
    deleteUserById, 
    deleteUsers,
    clearAllUsers 
};
