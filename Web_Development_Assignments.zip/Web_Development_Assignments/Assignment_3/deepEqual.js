'use strict';
// Don't add or change anything above this comment.

/*
* Don't change the declaration of this function.
*/
function deepEqual(val1, val2) {

  if (Object.is(val1, val2)) {
    return true;
  }
  
  if (val1 === null || val2 === null) {
    return val1 === val2; // true only if both are null
  }

  if (typeof val1 !== typeof val2) {
    return false;
  }


  if (Array.isArray(val1) && Array.isArray(val2)) {
    if (val1.length !== val2.length) {
      return false;
    }
    for (let i = 0; i < val1.length; i++) {
      if (!deepEqual(val1[i], val2[i])) {
        return false;
      }
    }
    return true;
  }

if (
  typeof val1 === 'object' &&
  typeof val2 === 'object' &&
  !Array.isArray(val1) &&
  !Array.isArray(val2)
) {
  const k1 = Object.keys(val1);
  const k2 = Object.keys(val2);

  if (k1.length !== k2.length) {
    return false;
  }

  for (const key of k1) {
    if (!(key in val2)) {
      return false;
    }
    if (!deepEqual(val1[key], val2[key])) {
      return false;
    }
  }

  return true;
}

return val1 === val2;

}

// Don't add or change anything below this comment.
module.exports = deepEqual;