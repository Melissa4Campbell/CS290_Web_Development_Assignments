import express from 'express';
import asyncHandler from 'express-async-handler';
import * as exercises from './exercise-model.mjs';

const router = express.Router();

const isValidExercise = (data) => {
    if (!data.name || !data.reps || data.weight === undefined || !data.unit) {
        return false;
    }
    if (typeof data.name !== 'string' || data.name.trim().length === 0) {
        return false;
    }
    if (typeof data.reps !== 'number' || !Number.isInteger(data.reps) || data.reps <= 0) {
        return false;
    }
    if (typeof data.weight !== 'number' || !Number.isInteger(data.weight) || data.weight < 0) {
        return false;
    }
    const validUnits = ['kgs', 'lbs', 'miles'];
    if (!validUnits.includes(data.unit)) {
        return false;
    }
    if (data.date) {
        const parsedDate = Date.parse(data.date);
        if (isNaN(parsedDate)) {
            return false;
        }
    }
    return true;
};

router.post('/exercises', asyncHandler(async (req, res) => {
    if (!isValidExercise(req.body)) {
        return res.status(400).json({ Error: 'Invalid request' });
    }
    const exercise = await exercises.createExercise(req.body);
    res.status(201).json(exercise);
}));

router.get('/exercises', asyncHandler(async (req, res) => {
    const allExercises = await exercises.findExercises();
    res.status(200).json(allExercises);
}));

router.get('/exercises/:_id', asyncHandler(async (req, res) => {
    const exercise = await exercises.findExerciseById(req.params._id);
    if (exercise === null) {
        return res.status(404).json({ Error: 'Not found' });
    }
    res.status(200).json(exercise);
}));

router.put('/exercises/:_id', asyncHandler(async (req, res) => {
    if (!isValidExercise(req.body)) {
        return res.status(400).json({ Error: 'Invalid request' });
    }
    const exercise = await exercises.updateExercise(req.params._id, req.body);
    if (exercise === null) {
        return res.status(404).json({ Error: 'Not found' });
    }
    res.status(200).json(exercise);
}));

router.delete('/exercises/:_id', asyncHandler(async (req, res) => {
    const exercise = await exercises.deleteExercise(req.params._id);
    if (exercise === null) {
        return res.status(404).json({ Error: 'Not found' });
    }
    res.status(204).send();
}));

export default router;