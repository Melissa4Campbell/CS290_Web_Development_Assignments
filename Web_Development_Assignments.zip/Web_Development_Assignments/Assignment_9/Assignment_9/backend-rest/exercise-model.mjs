import mongoose from 'mongoose';
import 'dotenv/config';

mongoose.connect(process.env.MONGODB_CONNECT_STRING);

const db = mongoose.connection;

db.once('open', () => {
    console.log('Successfully connected to MongoDB using Mongoose!');
});

const exerciseSchema = new mongoose.Schema({
    name: { type: String, required: true },
    reps: { type: Number, required: true },
    weight: { type: Number, required: true },
    unit: { type: String, required: true },
    date: { type: Date, required: true, default: Date.now }
});

const Exercise = mongoose.model('Exercise', exerciseSchema);

const createExercise = async (exerciseData) => {
    const exercise = new Exercise(exerciseData);
    return await exercise.save();
};

const findExercises = async () => {
    const exercises = await Exercise.find({});
    return exercises;
};

const findExerciseById = async (id) => {
    const exercise = await Exercise.findById(id);
    return exercise;
};

const updateExercise = async (id, update) => {
    const result = await Exercise.findByIdAndUpdate(
        id,
        update,
        { new: true, runValidators: true }
    );
    return result;
};

const deleteExercise = async (id) => {
    const result = await Exercise.findByIdAndDelete(id);
    return result;
};

export { createExercise, findExercises, findExerciseById, updateExercise, deleteExercise };