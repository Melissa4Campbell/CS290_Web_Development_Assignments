import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ExerciseTable from '../components/ExerciseTable';

function RetrieveExercises({ setExerciseToEdit }) {
    const [exercises, setExercises] = useState([]);
    const navigate = useNavigate();

    const loadExercises = async () => {
        try {
            const response = await fetch('/exercises');
            const data = await response.json();
            setExercises(data);
        } catch (error) {
            console.error('Error fetching exercises:', error);
            alert('Failed to load exercises');
        }
    };

    useEffect(() => {
        loadExercises();
    }, []);

    const onDelete = async (id) => {
        try {
            const response = await fetch(`/exercises/${id}`, {
                method: 'DELETE'
            });
            if (response.status === 204) {
                setExercises(exercises.filter(exercise => exercise._id !== id));
            } else {
                alert('Failed to delete exercise');
            }
        } catch (error) {
            console.error('Error deleting exercise:', error);
            alert('Failed to delete exercise');
        }
    };

    const onEdit = (exercise) => {
        setExerciseToEdit(exercise);
        navigate('/edit');
    };

    return (
        <div>
            <h2>Exercise List</h2>
            <p>View, edit, and delete your exercises below.</p>
            <ExerciseTable exercises={exercises} onDelete={onDelete} onEdit={onEdit} />
        </div>
    );
}

export default RetrieveExercises;