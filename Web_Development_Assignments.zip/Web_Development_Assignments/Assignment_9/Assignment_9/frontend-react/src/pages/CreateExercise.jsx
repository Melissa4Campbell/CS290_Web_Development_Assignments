import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function CreateExercise() {
    const [name, setName] = useState('');
    const [reps, setReps] = useState('');
    const [weight, setWeight] = useState('');
    const [unit, setUnit] = useState('lbs');
    const [date, setDate] = useState('');

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        const newExercise = {
            name,
            reps: parseInt(reps),
            weight: parseInt(weight),
            unit,
            date
        };

        try {
            const response = await fetch('/exercises', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newExercise)
            });

            if (response.status === 201) {
                alert('Exercise created successfully!');
                navigate('/');
            } else {
                alert('Failed to create exercise. Please check your input.');
                navigate('/');
            }
        } catch (error) {
            console.error('Error creating exercise:', error);
            alert('Failed to create exercise');
            navigate('/');
        }
    };

    return (
        <div>
            <h2>Create Exercise</h2>
            <p>Add a new exercise to your tracker.</p>
            <form onSubmit={handleSubmit}>
                <p>
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="reps">Reps:</label>
                    <input
                        type="number"
                        id="reps"
                        value={reps}
                        onChange={(e) => setReps(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="weight">Weight:</label>
                    <input
                        type="number"
                        id="weight"
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="unit">Unit:</label>
                    <select
                        id="unit"
                        value={unit}
                        onChange={(e) => setUnit(e.target.value)}
                        required
                    >
                        <option value="lbs">lbs</option>
                        <option value="kgs">kgs</option>
                        <option value="miles">miles</option>
                    </select>
                </p>

                <p>
                    <label htmlFor="date">Date:</label>
                    <input
                        type="date"
                        id="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        required
                    />
                </p>

                <button type="submit">Create</button>
            </form>
        </div>
    );
}

export default CreateExercise;