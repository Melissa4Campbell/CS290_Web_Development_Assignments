import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function EditExercise({ exerciseToEdit }) {
    const [name, setName] = useState(exerciseToEdit?.name || '');
    const [reps, setReps] = useState(exerciseToEdit?.reps || '');
    const [weight, setWeight] = useState(exerciseToEdit?.weight || '');
    const [unit, setUnit] = useState(exerciseToEdit?.unit || 'lbs');
    const [date, setDate] = useState(exerciseToEdit?.date?.split('T')[0] || '');

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        const updatedExercise = {
            name,
            reps: parseInt(reps),
            weight: parseInt(weight),
            unit,
            date
        };

        try {
            const response = await fetch(`/exercises/${exerciseToEdit._id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedExercise)
            });

            if (response.status === 200) {
                alert('Exercise updated successfully!');
                navigate('/');
            } else {
                alert('Failed to update exercise. Please check your input.');
                navigate('/');
            }
        } catch (error) {
            console.error('Error updating exercise:', error);
            alert('Failed to update exercise');
            navigate('/');
        }
    };

    return (
        <div>
            <h2>Edit Exercise</h2>
            <p>Update the exercise details below.</p>
            <form onSubmit={handleSubmit}>
                <p>
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="reps">Reps:</label>
                    <input
                        type="number"
                        id="reps"
                        value={reps}
                        onChange={(e) => setReps(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="weight">Weight:</label>
                    <input
                        type="number"
                        id="weight"
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        required
                    />
                </p>

                <p>
                    <label htmlFor="unit">Unit:</label>
                    <select
                        id="unit"
                        value={unit}
                        onChange={(e) => setUnit(e.target.value)}
                        required
                    >
                        <option value="lbs">lbs</option>
                        <option value="kgs">kgs</option>
                        <option value="miles">miles</option>
                    </select>
                </p>

                <p>
                    <label htmlFor="date">Date:</label>
                    <input
                        type="date"
                        id="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        required
                    />
                </p>

                <button type="submit">Update</button>
            </form>
        </div>
    );
}

export default EditExercise;