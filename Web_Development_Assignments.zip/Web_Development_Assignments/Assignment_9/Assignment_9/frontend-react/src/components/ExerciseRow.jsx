import React from 'react';
import { MdDelete, MdEdit } from 'react-icons/md';

function ExerciseRow({ exercise, onDelete, onEdit }) {
    return (
        <tr>
            <td>{exercise.name}</td>
            <td>{exercise.reps}</td>
            <td>{exercise.weight}</td>
            <td>{exercise.unit}</td>
            <td>{exercise.date?.split('T')[0]}</td>
            <td>
                <MdEdit onClick={() => onEdit(exercise)} />
            </td>
            <td>
                <MdDelete onClick={() => onDelete(exercise._id)} />
            </td>
        </tr>
    );
}

export default ExerciseRow;