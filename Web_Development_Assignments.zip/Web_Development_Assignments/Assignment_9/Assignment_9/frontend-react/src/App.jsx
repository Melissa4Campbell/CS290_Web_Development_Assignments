import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import RetrieveExercises from './pages/RetrieveExercises';
import CreateExercise from './pages/CreateExercise';
import EditExercise from './pages/EditExercise';
import './index.css';

function App() {
    const [exerciseToEdit, setExerciseToEdit] = useState(null);

    return (
        <Router>
            <header>
                <h1>My Personal Fitness Tracker</h1>
                <p>Create and Track your own workout journey and achieve your fitness goals</p>
            </header>

            <nav>
                <Link to="/">Home</Link>
                <Link to="/create">Create Exercise</Link>
            </nav>

            <main>
                <Routes>
                    <Route
                        path="/"
                        element={<RetrieveExercises setExerciseToEdit={setExerciseToEdit} />}
                    />
                    <Route
                        path="/create"
                        element={<CreateExercise />}
                    />
                    <Route
                        path="/edit"
                        element={<EditExercise exerciseToEdit={exerciseToEdit} />}
                    />
                </Routes>
            </main>

            <footer>
                <p>&copy; 2025 Melisa Campbell</p>
            </footer>
        </Router>
    );
}

export default App;