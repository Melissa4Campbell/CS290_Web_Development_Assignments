import express from 'express';
import * as model from './model.mjs';
const app = express();
const PORT = 3000;

app.use(express.json())

// Don't change or add anything above this line

app.get('/orders', (req, res) => {
  res.status(200).json(model.getAllOrders());
});

app.post('/orders', (req, res) => {
  const { company, quantity } = req.body || {};

  const validCompany = typeof company === 'string' && company.trim().length >= 2;
  const q = Number(quantity);
  const validQuantity = Number.isInteger(q) && q > 0;

  if (!validCompany || !validQuantity) {
    return res.status(400).json({ Error: 'Invalid request' });
  }

  const created = model.createOrder(company.trim(), q);
  return res.status(201).json(created);
});

app.get('/orders/:id', (req, res) => {
  const id = req.params.id;
  const order = model.getOrderById(id);

  if (!order) {
    return res.status(404).json({ Error: 'Not found' });
  }

  return res.status(200).json(order);
});

app.put('/orders/:id', (req, res) => {
  const id = req.params.id;
  const q = Number(req.body?.quantity);

  // If quantity is missing or invalid, return 400 first
  if (!Number.isInteger(q) || q <= 0) {
    return res.status(400).json({ Error: 'Invalid request' });
  }

  const updated = model.updateOrderQuantity(id, q);

  // If no order found
  if (updated === null) {
    return res.status(404).json({ Error: 'Not found' });
  }

  // If model returned invalid (shouldn’t happen here)
  if (updated.error === 'invalid') {
    return res.status(400).json({ Error: 'Invalid request' });
  }

  return res.status(200).json(updated);
});

app.delete('/orders/:id', (req, res) => {
  const id = req.params.id;
  const deleted = model.deleteOrderById(id);

  if (!deleted) {
    return res.status(404).json({ Error: 'Not found' });
  }

  return res.status(204).send(); // 204 = No Content
});


// Don't change or add anything below this line
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}...`);
});