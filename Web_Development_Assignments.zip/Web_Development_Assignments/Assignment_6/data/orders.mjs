import Order from '../order.mjs';

const orders = [
      new Order('ORCL', 87),
      new Order('MSFT', 44)
];

export default orders;