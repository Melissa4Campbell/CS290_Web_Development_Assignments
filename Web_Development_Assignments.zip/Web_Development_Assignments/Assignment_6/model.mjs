import orders from './data/orders.mjs';
import Order from './order.mjs';

export function getAllOrders() {
  return orders;
}
/**
 * 
 * @param {string} company 
 * @param {number} quantity 
 * @returns 
 */
function createOrder(company, quantity){
    const order = new Order(company, quantity)
    orders.push(order)
    return order
}

export function updateOrderQuantity(id, quantity) {
  if (!Number.isInteger(quantity) || quantity <= 0) return { error: 'invalid' };
  const o = orders.find(o => o.id === id);
  if (!o) return null;
  o.quantity = quantity;
  return o;
}

export function deleteOrderById(id) {
  const idx = orders.findIndex(o => o.id === id);
  if (idx === -1) return false;
  orders.splice(idx, 1);
  return true;
}


// Don't change anything above this line
export function getOrderById(id) {
  return orders.find(o => o.id === id) || null;
}



export {createOrder};